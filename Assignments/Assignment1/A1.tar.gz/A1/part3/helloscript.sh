echo Hej hej
echo How are you?
echo I am good. wbu?
