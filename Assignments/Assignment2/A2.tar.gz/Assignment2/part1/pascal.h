#include <stdio.h>
#include <stdlib.h>

void printPascal(int n);
int binomialCoeff(int n, int k);
int factorial(int n, int t);
