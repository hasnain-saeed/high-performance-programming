#include "linkedlist.h"

int main(){
    listNode_t *head = NULL;
    char command;
    int day;
    float min, max;
    do
    {
        printf("Enter command: ");
        scanf(" %c", &command);
        switch (command)
        {
        case 'A':
            scanf("%d %f %f", &day, &min, &max);
            addNoteInList(&head, day, min, max);
            break;
        case 'D':
            scanf("%d", &day);
            deleteNoteFromList(&head, day);
            break;
        case 'P':
            printList(head);
            break;
        case 'Q': break;
        default:
            printf("Incorrect command!\n");
            break;
        }
    } while (command != 'Q');
    deleteList(&head);
    return 0;
}
