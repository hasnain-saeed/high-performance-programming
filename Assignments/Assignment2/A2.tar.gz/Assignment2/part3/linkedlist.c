#include "linkedlist.h"

listNode_t* createNode(int day, float min, float max){
    listNode_t* node = (listNode_t*)malloc(sizeof(listNode_t));
    node->day = day;
    node->min = min;
    node->max = max;
    node->next = NULL;
    return node;
}

void addNoteInList(listNode_t** head, int day, float min, float max){
    if (*head == NULL){
        *head = createNode(day, min, max);
    }
    if(day < (*head)->day){
        listNode_t* newHead = createNode(day, min, max);
        newHead->next = *head;
        *head = newHead;
        return;
    }
    else if(day == (*head)->day) {
        (*head)->min = min;
        (*head)->max = max;
        return;
    }
    else {
        addNoteInList((&(*head)->next), day, min, max);
    }
}

void deleteNoteFromList(listNode_t** head, int day){
    if(*head == NULL){
        return;
    }

    if ((*head)->day == day){
        listNode_t* temp = *head;
        *head = (*head)->next;
        free(temp);
        return;
    }

    listNode_t* temp = *head;

    while (temp->next != NULL){
        if (temp->next->day == day) {
            listNode_t* node = temp->next;
            temp->next = temp->next->next;
            free(node);
            return;
        }
        temp = temp->next;
    }
}

void printList(listNode_t* head) {
    printf("%-6s %-10s %-10s\n", "day", "min", "max");
    while (head != NULL) {
        printf("%-6d %9.6f %9.6f\n", head->day, head->min, head->max);
        head = head->next;
    }
}

void deleteList(listNode_t** head){
    if(*head == NULL){
        return;
    }
    deleteList(&((*head)->next));
    free(*head);
    *head = NULL;
}
