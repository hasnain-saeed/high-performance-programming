#include <stdio.h>
#include <stdlib.h>

typedef struct listNode
{
   int day;
   float min;
   float max;
   struct listNode *next;
} listNode_t;

listNode_t* createNode(int, float, float);
void addNoteInList(listNode_t**, int, float, float);
void deleteNoteFromList(listNode_t**, int);
void printList(listNode_t*);
void deleteList(listNode_t**);
